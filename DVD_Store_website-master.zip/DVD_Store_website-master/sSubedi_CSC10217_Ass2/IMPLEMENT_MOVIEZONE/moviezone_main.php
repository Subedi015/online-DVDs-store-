<?php
/*-------------------------------------------------------------------------------------------------
@Module: moviezone_main.php
This server-side main module interacts with UI to process user's requests

@Modified by: Salim Subedi
@Date: 25/09/2018
@version: 2.9

@Modified from: bv_caryard code files whose author is Vinh Bui   
--------------------------------------------------------------------------------------------------*/
require_once('moviezone_config.php'); 

/*initialize the model and view
*/
$model = new MovieZoneModel();
$view = new MovieZoneView();
$controller = new MovieZoneController($model, $view);
/*interacts with UI via GET/POST methods and process all requests
*/
if (!empty($_REQUEST[CMD_REQUEST])) { //check if there is a request to process
	$request = $_REQUEST[CMD_REQUEST];
	$controller->processRequest($request);
}
?>