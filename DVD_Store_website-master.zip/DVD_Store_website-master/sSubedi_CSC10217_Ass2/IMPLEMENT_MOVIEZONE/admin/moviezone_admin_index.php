<?php
/*-------------------------------------------------------------------------------------------------
@Module: moviezone_admin_index.php
This server-side module provides main UI for the application (admin part)

@Author: Vinh Bui (vinh.bui@scu.edu.au)
@Modified by: Salim Subedi
@Date: 01/10/2018
-------------------------------------------------------------------------------------------------*/
require_once('moviezone_admin_main.php');
?>

<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/Moviezone_admin.css">
	<link rel="stylesheet" type="text/css" href="css/Moviezone_form.css">
	<script src="js/ajax.js"></script>
	<script src="js/moviezone_admin.js"></script>
</head>

<body>
<div id="id_container">
	<header>
		<h1>MOVIEZONE EMPORIUM - ADMIN MODE</h1>
		<h2><?php echo "(Loggedin as: ".$_SESSION['authorised'].")"?></h2>
	</header>
	<!-- left navigation area -->
	<div id="id_left">
		<!-- load the navigation panel by embedding php code -->
		<?php $controller->loadLeftNavPanel()?>
	</div>
	<!-- right area -->	
	<div id="id_right">
		<!-- top navigation area -->
		<div id="id_topnav">
			<!-- the top navigation panel is loaded on demand using Ajax (see js code) -->
		</div>

		<div id="id_content"></div>
	</div>
	<!-- footer area -->
	<footer>Copyright &copy; s.subedi.11@student.scu.edu.au (Web Dev II) </footer>
</div>
</body>
</html>